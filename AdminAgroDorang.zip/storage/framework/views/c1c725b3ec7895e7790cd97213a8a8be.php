<div class="d-flex">
    <a href="<?php echo e(route('mahals.edit', ['mahal' => $mahal->id])); ?>" class="btn btn-outline-primary btn-sm me-2"><i class="bi-pencil-square"></i></a>

    <div>
        <form action="<?php echo e(route('mahals.destroy', ['mahal' => $mahal->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm me-2 btn-delete">
                <i class="bi-trash"></i>
            </button>
        </form>

    </div>
</div>
<?php /**PATH D:\Job\Project\ArgoDorang\AdminAgroDorang\resources\views/actions/actionmahal.blade.php ENDPATH**/ ?>