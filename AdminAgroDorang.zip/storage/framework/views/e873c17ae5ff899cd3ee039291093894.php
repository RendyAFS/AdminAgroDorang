<form action="<?php echo e(route('murahs.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <!-- CSRF token -->

    <div class="form-group mt-3">
        <label for="nama_product" class="fw-bold">Nama Produk:</label>
        <input type="text" class="form-control border-dark" id="nama_product" name="nama_product"
            value="<?php echo e(old('nama_product')); ?>" required>
    </div>
    <div class="form-group mt-3 row">
        <div class="col-md-8">
            <label for="harga_product" class="fw-bold ">Harga Produk:</label>
            <input type="number" class="form-control border-dark" id="harga_product" name="harga_product"
                value="<?php echo e(old('harga_product')); ?>" required>
        </div>
        <div class="col-md-4">
            <label for="satuans_id" class="fw-bold">Satuan</label>
            <select name="satuans_id" id="table_satuans_id" class="form-select border-dark" required>
                <option value=""></option>
                <?php $__currentLoopData = $satuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($satuan->id); ?>">
                        /<?php echo e($satuan->nama_satuan); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <div class="form-group mt-3">
        <label for="deskripsi_product" class="fw-bold">Deskripsi Produk:</label>
        <div class="p-1">
            <textarea style="width: 100%;" cols="100" rows="5" id="deskripsi_product" name="deskripsi_product" required><?php echo e(old('deskripsi_product')); ?></textarea>
        </div>
    </div>

    <div class="form-group mt-3">
        <label for="gambar_product" class="fw-bold">Gambar Product:</label>
        <input type="file" class="form-control border-dark <?php $__errorArgs = ['gambar_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gambar_product" name="gambar_product" value="<?php echo e(old('gambar_product')); ?>" required>
        <?php $__errorArgs = ['gambar_product'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger text-left"><?php echo e($message); ?></small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="form-group mt-3">
        <label for="stok_product" class="fw-bold">Stok Produk:</label>
        <input type="text" class="form-control border-dark" id="stok_product" name="stok_product"
            value="<?php echo e(old('stok_product')); ?>" required>
    </div>



    <div class="row mt-4">
        <div class="col-3"></div>
        <div class="col-3 d-grid">
            <button type="submit" class="btn btn-primary shadow">Tambah</button>
        </div>
        <div class="col-3 d-grid">
            <a href="Batal" class="btn btn-danger me-1 shadow" data-bs-dismiss="modal" aria-label="Close">
                Batal
            </a>
        </div>
        <div class="col-3"></div>
    </div>
</form>
<?php /**PATH D:\Job\Project\ArgoDorang\AdminAgroDorang\resources\views/actions/TambahProductMurah.blade.php ENDPATH**/ ?>